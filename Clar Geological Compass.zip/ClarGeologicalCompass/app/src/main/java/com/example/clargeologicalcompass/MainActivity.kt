package com.example.clargeologicalcompass

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var sensorDataAdapter: SensorDataAdapter
    private lateinit var database: DatabaseReference
    private val sensorDataList = mutableListOf<SensorData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        sensorDataAdapter = SensorDataAdapter(sensorDataList)
        recyclerView.adapter = sensorDataAdapter

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().getReference("sensor_data")

        // Read data from Firebase
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                sensorDataList.clear()
                for (dataSnapshot in snapshot.children) {
                    val data = dataSnapshot.getValue(SensorData::class.java)
                    data?.let { sensorDataList.add(it) }
                }
                sensorDataAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Firebase", "Error fetching data", error.toException())
            }
        })

        // Initialize Delete Button and set its OnClickListener
        val deleteButton: Button = findViewById(R.id.deleteButton)
        deleteButton.setOnClickListener {
            database.removeValue().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    sensorDataList.clear()
                    sensorDataAdapter.notifyDataSetChanged()
                    Toast.makeText(this, "All data deleted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to delete data", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
