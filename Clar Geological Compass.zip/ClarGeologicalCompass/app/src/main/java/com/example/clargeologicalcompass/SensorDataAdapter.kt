package com.example.clargeologicalcompass

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SensorDataAdapter(private val dataList: List<SensorData>) :
    RecyclerView.Adapter<SensorDataAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val slNoText: TextView = view.findViewById(R.id.textSlNo)
        val timestampText: TextView = view.findViewById(R.id.textTimestamp)
        val strikeValueText: TextView = view.findViewById(R.id.textStrikeValue)  // new
        val dipValueText: TextView = view.findViewById(R.id.textDipValue)        // new
        val dipDirValueText: TextView = view.findViewById(R.id.textDipDirValue)  // new
        val gpsText: TextView = view.findViewById(R.id.textGPS)                  // new
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate the updated layout (see next section)
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sensor_data, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = dataList[position]
        holder.slNoText.text = data.slNo.toString()
        holder.timestampText.text = data.timestamp
        holder.strikeValueText.text = data.strikeValue.toString()
        holder.dipValueText.text = data.dipValue.toString()
        holder.dipDirValueText.text = data.dipDirValue.toString()
        holder.gpsText.text = data.gps
    }

    override fun getItemCount() = dataList.size
}
