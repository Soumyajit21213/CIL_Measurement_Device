package com.example.clargeologicalcompass

data class SensorData(
    val slNo: Int = 0,
    val timestamp: String = "",
    val strikeValue: Int = 0,
    val dipValue: Int = 0,
    val dipDirValue: Int = 0,
    val gps: String = ""
)
